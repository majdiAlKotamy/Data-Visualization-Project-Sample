```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
```


```python
df = pd.read_csv(r"C:\Users\vmsof\Desktop\test.csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customer_id</th>
      <th>vintage</th>
      <th>age</th>
      <th>gender</th>
      <th>dependents</th>
      <th>occupation</th>
      <th>city</th>
      <th>customer_nw_category</th>
      <th>branch_code</th>
      <th>current_balance</th>
      <th>current_month_credit</th>
      <th>current_month_debit</th>
      <th>current_month_balance</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>2101</td>
      <td>66</td>
      <td>Male</td>
      <td>0.0</td>
      <td>self_employed</td>
      <td>187.0</td>
      <td>2</td>
      <td>755</td>
      <td>1458.71</td>
      <td>0.20</td>
      <td>0.20</td>
      <td>1458.71</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>2348</td>
      <td>35</td>
      <td>Male</td>
      <td>0.0</td>
      <td>self_employed</td>
      <td>NaN</td>
      <td>2</td>
      <td>3214</td>
      <td>5390.37</td>
      <td>0.56</td>
      <td>5486.27</td>
      <td>6496.78</td>
    </tr>
    <tr>
      <th>2</th>
      <td>4</td>
      <td>2194</td>
      <td>31</td>
      <td>Male</td>
      <td>0.0</td>
      <td>salaried</td>
      <td>146.0</td>
      <td>2</td>
      <td>41</td>
      <td>3913.16</td>
      <td>0.61</td>
      <td>6046.73</td>
      <td>5006.28</td>
    </tr>
    <tr>
      <th>3</th>
      <td>5</td>
      <td>2329</td>
      <td>90</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>self_employed</td>
      <td>1020.0</td>
      <td>2</td>
      <td>582</td>
      <td>2291.91</td>
      <td>0.47</td>
      <td>0.47</td>
      <td>2291.91</td>
    </tr>
    <tr>
      <th>4</th>
      <td>6</td>
      <td>1579</td>
      <td>42</td>
      <td>Male</td>
      <td>2.0</td>
      <td>self_employed</td>
      <td>1494.0</td>
      <td>3</td>
      <td>388</td>
      <td>927.72</td>
      <td>0.33</td>
      <td>588.62</td>
      <td>1157.15</td>
    </tr>
    <tr>
      <th>5</th>
      <td>7</td>
      <td>1923</td>
      <td>42</td>
      <td>Female</td>
      <td>0.0</td>
      <td>self_employed</td>
      <td>1096.0</td>
      <td>2</td>
      <td>1666</td>
      <td>15202.20</td>
      <td>0.36</td>
      <td>857.50</td>
      <td>15719.44</td>
    </tr>
    <tr>
      <th>6</th>
      <td>8</td>
      <td>2048</td>
      <td>72</td>
      <td>Male</td>
      <td>0.0</td>
      <td>retired</td>
      <td>1020.0</td>
      <td>1</td>
      <td>1</td>
      <td>7006.93</td>
      <td>0.64</td>
      <td>1299.64</td>
      <td>7076.06</td>
    </tr>
    <tr>
      <th>7</th>
      <td>9</td>
      <td>2009</td>
      <td>46</td>
      <td>Male</td>
      <td>0.0</td>
      <td>self_employed</td>
      <td>623.0</td>
      <td>2</td>
      <td>317</td>
      <td>10096.58</td>
      <td>0.27</td>
      <td>443.13</td>
      <td>8563.84</td>
    </tr>
    <tr>
      <th>8</th>
      <td>10</td>
      <td>2053</td>
      <td>31</td>
      <td>Male</td>
      <td>0.0</td>
      <td>salaried</td>
      <td>1096.0</td>
      <td>2</td>
      <td>4110</td>
      <td>1355.86</td>
      <td>714.51</td>
      <td>714.51</td>
      <td>1183.45</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.set_index('customer_id')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>vintage</th>
      <th>age</th>
      <th>gender</th>
      <th>dependents</th>
      <th>occupation</th>
      <th>city</th>
      <th>customer_nw_category</th>
      <th>branch_code</th>
      <th>current_balance</th>
      <th>current_month_credit</th>
      <th>current_month_debit</th>
      <th>current_month_balance</th>
    </tr>
    <tr>
      <th>customer_id</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2101</td>
      <td>66</td>
      <td>Male</td>
      <td>0.0</td>
      <td>self_employed</td>
      <td>187.0</td>
      <td>2</td>
      <td>755</td>
      <td>1458.71</td>
      <td>0.20</td>
      <td>0.20</td>
      <td>1458.71</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2348</td>
      <td>35</td>
      <td>Male</td>
      <td>0.0</td>
      <td>self_employed</td>
      <td>NaN</td>
      <td>2</td>
      <td>3214</td>
      <td>5390.37</td>
      <td>0.56</td>
      <td>5486.27</td>
      <td>6496.78</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2194</td>
      <td>31</td>
      <td>Male</td>
      <td>0.0</td>
      <td>salaried</td>
      <td>146.0</td>
      <td>2</td>
      <td>41</td>
      <td>3913.16</td>
      <td>0.61</td>
      <td>6046.73</td>
      <td>5006.28</td>
    </tr>
    <tr>
      <th>5</th>
      <td>2329</td>
      <td>90</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>self_employed</td>
      <td>1020.0</td>
      <td>2</td>
      <td>582</td>
      <td>2291.91</td>
      <td>0.47</td>
      <td>0.47</td>
      <td>2291.91</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1579</td>
      <td>42</td>
      <td>Male</td>
      <td>2.0</td>
      <td>self_employed</td>
      <td>1494.0</td>
      <td>3</td>
      <td>388</td>
      <td>927.72</td>
      <td>0.33</td>
      <td>588.62</td>
      <td>1157.15</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1923</td>
      <td>42</td>
      <td>Female</td>
      <td>0.0</td>
      <td>self_employed</td>
      <td>1096.0</td>
      <td>2</td>
      <td>1666</td>
      <td>15202.20</td>
      <td>0.36</td>
      <td>857.50</td>
      <td>15719.44</td>
    </tr>
    <tr>
      <th>8</th>
      <td>2048</td>
      <td>72</td>
      <td>Male</td>
      <td>0.0</td>
      <td>retired</td>
      <td>1020.0</td>
      <td>1</td>
      <td>1</td>
      <td>7006.93</td>
      <td>0.64</td>
      <td>1299.64</td>
      <td>7076.06</td>
    </tr>
    <tr>
      <th>9</th>
      <td>2009</td>
      <td>46</td>
      <td>Male</td>
      <td>0.0</td>
      <td>self_employed</td>
      <td>623.0</td>
      <td>2</td>
      <td>317</td>
      <td>10096.58</td>
      <td>0.27</td>
      <td>443.13</td>
      <td>8563.84</td>
    </tr>
    <tr>
      <th>10</th>
      <td>2053</td>
      <td>31</td>
      <td>Male</td>
      <td>0.0</td>
      <td>salaried</td>
      <td>1096.0</td>
      <td>2</td>
      <td>4110</td>
      <td>1355.86</td>
      <td>714.51</td>
      <td>714.51</td>
      <td>1183.45</td>
    </tr>
  </tbody>
</table>
</div>




```python
group_by_frame = df.groupby('occupation')
```


```python
print(plt.style.available)
plt.style.use('fivethirtyeight')
```

    ['Solarize_Light2', '_classic_test_patch', '_mpl-gallery', '_mpl-gallery-nogrid', 'bmh', 'classic', 'dark_background', 'fast', 'fivethirtyeight', 'ggplot', 'grayscale', 'seaborn-v0_8', 'seaborn-v0_8-bright', 'seaborn-v0_8-colorblind', 'seaborn-v0_8-dark', 'seaborn-v0_8-dark-palette', 'seaborn-v0_8-darkgrid', 'seaborn-v0_8-deep', 'seaborn-v0_8-muted', 'seaborn-v0_8-notebook', 'seaborn-v0_8-paper', 'seaborn-v0_8-pastel', 'seaborn-v0_8-poster', 'seaborn-v0_8-talk', 'seaborn-v0_8-ticks', 'seaborn-v0_8-white', 'seaborn-v0_8-whitegrid', 'tableau-colorblind10']
    


```python
df.plot(kind='line', title = 'Analyzing Bank Customer Behavior',use_index = True , xlabel='Daily Rating' , ylabel='Scores', figsize = (10,5), grid = True)
```




    <Axes: title={'center': 'Analyzing Bank Customer Behavior'}, xlabel='Daily Rating', ylabel='Scores'>




    
![png](output_5_1.png)
    



```python
df.plot(kind= 'bar',figsize = (10,7), stacked= True)
```




    <Axes: >




    
![png](output_6_1.png)
    



```python
df.plot.barh(stacked=True,figsize = (10,5))
```




    <Axes: >




    
![png](output_7_1.png)
    



```python
df.plot.scatter(x='customer_id',y='occupation',figsize = (5,3), s=100, c= 'Blue')
```




    <Axes: xlabel='customer_id', ylabel='occupation'>




    
![png](output_8_1.png)
    



```python
df.plot.hist(bins=50)
```




    <Axes: ylabel='Frequency'>




    
![png](output_9_1.png)
    



```python
df.plot.area(figsize=(10,7))
```




    <Axes: >




    
![png](output_10_1.png)
    



```python
df.plot.pie(y='vintage', figsize=(10,6))
```




    <Axes: ylabel='vintage'>




    
![png](output_11_1.png)
    



```python
print(plt.style.available)
plt.style.use('seaborn-v0_8-deep')
```

    ['Solarize_Light2', '_classic_test_patch', '_mpl-gallery', '_mpl-gallery-nogrid', 'bmh', 'classic', 'dark_background', 'fast', 'fivethirtyeight', 'ggplot', 'grayscale', 'seaborn-v0_8', 'seaborn-v0_8-bright', 'seaborn-v0_8-colorblind', 'seaborn-v0_8-dark', 'seaborn-v0_8-dark-palette', 'seaborn-v0_8-darkgrid', 'seaborn-v0_8-deep', 'seaborn-v0_8-muted', 'seaborn-v0_8-notebook', 'seaborn-v0_8-paper', 'seaborn-v0_8-pastel', 'seaborn-v0_8-poster', 'seaborn-v0_8-talk', 'seaborn-v0_8-ticks', 'seaborn-v0_8-white', 'seaborn-v0_8-whitegrid', 'tableau-colorblind10']
    


```python

```
